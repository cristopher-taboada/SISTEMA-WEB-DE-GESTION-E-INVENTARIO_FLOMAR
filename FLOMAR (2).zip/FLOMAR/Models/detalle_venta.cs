﻿namespace FLOMAR.Models
{
    public class detalle_venta
    {
        public int Id_detalle_venta { get; set; }
        public int id_venta { get; set; }
        public int id_repuesto { get; set; }
       
        public int cantidad { get; set; }
        public decimal precio_unitario { get; set; }
        public decimal subtotal { get; set; }


    }
}
